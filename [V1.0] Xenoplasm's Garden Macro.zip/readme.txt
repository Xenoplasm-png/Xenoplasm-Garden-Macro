INSTALLATION STEPS:

 - Make sure you have AutoHotkey v1.1 (deprecated) installed
 - Run the macro and enjoy :)

WARNING:

 - DO NOT USE ANY PETS THAT MODIFY PLAYER SPEED AS THIS WILL BREAK THE MACRO